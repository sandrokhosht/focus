package com.example.fuckjson.common;

import android.content.SharedPreferences;
import android.content.Context;
import com.example.fuckjson.GameApplication;
import static android.content.Context.MODE_PRIVATE;



public class Memory {

    public static final String SHARED_PREFS = "sharedPrefs";
    public static final int MONEY = 0;
    public static int playerMoney;



    public static int getMoneyData(){
        SharedPreferences sp = GameApplication.getContext().getApplicationContext().getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);
        int myMoneyValue = sp.getInt("MONEY", 0);
        playerMoney = myMoneyValue;
        return playerMoney;
    }

    public static void changeMoneyData(int moneyToChange){
        SharedPreferences sp = GameApplication.getContext().getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        // int valueToChange=Integer.parseInt(moneyToChange);  // converting string to int
        playerMoney+=moneyToChange; // adding value to moneyMoney
        editor.putInt("MONEY", playerMoney); // put value to its key
        editor.apply();
    }


}
