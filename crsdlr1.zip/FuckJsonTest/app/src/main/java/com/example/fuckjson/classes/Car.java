package com.example.fuckjson.classes;

import java.util.Random;

public class Car {



    public String carName;
    public int carMileage;


    public Car(String carName,int carMileage){
        this.carName=carName;
        this.carMileage=carMileage;
    }





}
