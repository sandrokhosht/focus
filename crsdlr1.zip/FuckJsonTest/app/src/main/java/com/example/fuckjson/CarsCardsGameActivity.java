package com.example.fuckjson;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class CarsCardsGameActivity extends AppCompatActivity {


    String[] carArray={"mercedes","nissan","hyundai"};


    Button box11,box12,box13,box21,box22,box23,box31,box32,box33;
    int revealed=0;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cars_cards_game_activity);

        box11 = findViewById(R.id.box11);
        box11 = findViewById(R.id.box12);
        box11 = findViewById(R.id.box13);
        box11 = findViewById(R.id.box21);
        box11 = findViewById(R.id.box22);
        box11 = findViewById(R.id.box23);
        box11 = findViewById(R.id.box31);
        box11 = findViewById(R.id.box32);
        box11 = findViewById(R.id.box33);






    }


   /* box11.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            box11.setBackgroundResource(R.drawable.mercedes);
        }
    });*/

    public String getRandomCarName() {
        int rnd = new Random().nextInt(carArray.length);
        return carArray[rnd];
    }




}
