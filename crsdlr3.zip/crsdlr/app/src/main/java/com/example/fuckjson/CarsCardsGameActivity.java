package com.example.fuckjson;

import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;

public class CarsCardsGameActivity extends AppCompatActivity implements View.OnClickListener {


    public String[] carArray={"mercedes","nissan","hyundai","mercedes","nissan","hyundai","mercedes","nissan","hyundai"};
    HashMap<String,Integer> revealedHM=new HashMap<String, Integer>() {{
            put("mercedes",3);
            put("hyundai",3);
            put("nissan",3);
    }};

    TextView textMessage;
    Button box11,box12,box13,box21,box22,box23,box31,box32,box33;
    Button tryAgain_btn;
    private int revealedCards=3;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cars_cards_game_activity);

        init();
        shuffleArray();

    }

public void init(){

    textMessage = findViewById(R.id.textMessage);
    tryAgain_btn = findViewById(R.id.tryAgain_btn);

    box11 = findViewById(R.id.box11);
    box11.setOnClickListener(this);
    box12 = findViewById(R.id.box12);
    box12.setOnClickListener(this);
    box13 = findViewById(R.id.box13);
    box13.setOnClickListener(this);
    box21 = findViewById(R.id.box21);
    box21.setOnClickListener(this);
    box22 = findViewById(R.id.box22);
    box22.setOnClickListener(this);
    box23 = findViewById(R.id.box23);
    box23.setOnClickListener(this);
    box31 = findViewById(R.id.box31);
    box31.setOnClickListener(this);
    box32 = findViewById(R.id.box32);
    box32.setOnClickListener(this);
    box33 = findViewById(R.id.box33);
    box33.setOnClickListener(this);
}


    public void shuffleArray() {

        Random rand = new Random();

        for (int i = 0; i < carArray.length; i++) {
            int randomIndexToSwap = rand.nextInt(carArray.length);
            String temp = carArray[randomIndexToSwap];
            carArray[randomIndexToSwap] = carArray[i];
            carArray[i] = temp;
        }

    }




    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.box11:
                box11.setBackgroundResource(getResources().getIdentifier(carArray[0], "drawable", getPackageName()));
                revealedHM.put(carArray[0],revealedHM.get(carArray[0])-1);
                box11.setEnabled(false);
                revealedCards--;
                terminateRevealChecker();
                break;
            case R.id.box12:
                box12.setBackgroundResource(getResources().getIdentifier(carArray[1], "drawable", getPackageName()));
                revealedHM.put(carArray[1],revealedHM.get(carArray[1])-1);
                box12.setEnabled(false);
                revealedCards--;
                terminateRevealChecker();
                break;
            case R.id.box13:
                box13.setBackgroundResource(getResources().getIdentifier(carArray[2], "drawable", getPackageName()));
                revealedHM.put(carArray[2],revealedHM.get(carArray[2])-1);
                box13.setEnabled(false);
                revealedCards--;
                terminateRevealChecker();
                break;
            case R.id.box21:
                box21.setBackgroundResource(getResources().getIdentifier(carArray[3], "drawable", getPackageName()));
                revealedHM.put(carArray[3],revealedHM.get(carArray[3])-1);
                box21.setEnabled(false);
                revealedCards--;
                terminateRevealChecker();
                break;
            case R.id.box22:
                box22.setBackgroundResource(getResources().getIdentifier(carArray[4], "drawable", getPackageName()));
                revealedHM.put(carArray[4],revealedHM.get(carArray[4])-1);
                box22.setEnabled(false);
                revealedCards--;
                terminateRevealChecker();
                break;
            case R.id.box23:
                box23.setBackgroundResource(getResources().getIdentifier(carArray[5], "drawable", getPackageName()));
                revealedHM.put(carArray[5],revealedHM.get(carArray[5])-1);
                box23.setEnabled(false);
                revealedCards--;
                terminateRevealChecker();
                break;
            case R.id.box31:
                box31.setBackgroundResource(getResources().getIdentifier(carArray[6], "drawable", getPackageName()));
                revealedHM.put(carArray[6],revealedHM.get(carArray[6])-1);
                box31.setEnabled(false);
                revealedCards--;
                terminateRevealChecker();
                break;
            case R.id.box32:
                box32.setBackgroundResource(getResources().getIdentifier(carArray[7], "drawable", getPackageName()));
                revealedHM.put(carArray[7],revealedHM.get(carArray[7])-1);
                box32.setEnabled(false);
                revealedCards--;
                terminateRevealChecker();
                break;
            case R.id.box33:
                box33.setBackgroundResource(getResources().getIdentifier(carArray[8], "drawable", getPackageName()));
                revealedHM.put(carArray[8],revealedHM.get(carArray[8])-1);
                box33.setEnabled(false);
                revealedCards--;
                terminateRevealChecker();
                break;
        }
    }

    public void terminateRevealChecker(){
        if(revealedCards<=0){
        box11.setEnabled(false);
        box12.setEnabled(false);
        box13.setEnabled(false);
        box21.setEnabled(false);
        box22.setEnabled(false);
        box23.setEnabled(false);
        box31.setEnabled(false);
        box32.setEnabled(false);
        box33.setEnabled(false);
        if(revealedHM.get("mercedes")==0){
            textMessage.setText("You won Mercedes");
        }
        else if (revealedHM.get("hyundai")==0){
            textMessage.setText("You won Hyundai");
        }
        else if (revealedHM.get("nissan")==0){
            textMessage.setText("You won Nissan");
        }
        else textMessage.setText("You didn't win anything");
        }
    }

    public void tryAgain(View v){
        shuffleArray();
        textMessage.setText("123");
        revealedCards=3;
        revealedHM.put("mercedes",3);
        revealedHM.put("hyundai",3);
        revealedHM.put("nissan",3);


        box11.setBackgroundResource(R.drawable.buttonstyle);
        box12.setBackgroundResource(R.drawable.buttonstyle);
        box13.setBackgroundResource(R.drawable.buttonstyle);
        box21.setBackgroundResource(R.drawable.buttonstyle);
        box22.setBackgroundResource(R.drawable.buttonstyle);
        box23.setBackgroundResource(R.drawable.buttonstyle);
        box31.setBackgroundResource(R.drawable.buttonstyle);
        box32.setBackgroundResource(R.drawable.buttonstyle);
        box33.setBackgroundResource(R.drawable.buttonstyle);
        box11.setEnabled(true);
        box12.setEnabled(true);
        box13.setEnabled(true);
        box21.setEnabled(true);
        box22.setEnabled(true);
        box23.setEnabled(true);
        box31.setEnabled(true);
        box32.setEnabled(true);
        box33.setEnabled(true);

    }
}
