package com.example.fuckjson;

import android.app.Application;
import android.content.Context;

public class GameApplication extends Application {

    private static Context context;

    public void onCreate() {
        super.onCreate();
        GameApplication.context = getApplicationContext();
    }

    public static Context getContext() {
        return GameApplication.context;
    }

}
