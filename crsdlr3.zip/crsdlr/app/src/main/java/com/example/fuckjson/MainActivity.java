package com.example.fuckjson;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import com.example.fuckjson.common.Memory;
import java.math.BigDecimal;
import java.util.Random;
import com.example.fuckjson.classes.Car;


public class MainActivity extends AppCompatActivity {






    TextView playerMoney_tv;
    Dialog checkCarDialog;
    Button carsCardsGame_btn;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);


        checkCarDialog = new Dialog(this);
        playerMoney_tv = findViewById(R.id.playerMoney_tv);
        carsCardsGame_btn = findViewById(R.id.carsCardsGame_btn);

        playerMoney_tv.setText(String.valueOf(Memory.getMoneyData()));






    }





        public void openCarsCardsGameActivity(View v){
            Intent intent = new Intent(this, CarsCardsGameActivity.class);
            startActivity(intent);
        }









    public void checkCar_btn(View v){
        TextView txtclose;
        Button btnBuyCar;
        checkCarDialog.setContentView(R.layout.check_car_popup);
        txtclose = (TextView) checkCarDialog.findViewById(R.id.txtclose);
        btnBuyCar = (Button) checkCarDialog.findViewById(R.id.buyCar_btn);
        txtclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkCarDialog.dismiss();
            }
        });
        checkCarDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        checkCarDialog.show();



        btnBuyCar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Memory.changeMoneyData(-9000);
                playerMoney_tv.setText(String.valueOf(Memory.getMoneyData()));


            }
        });
    }



















}