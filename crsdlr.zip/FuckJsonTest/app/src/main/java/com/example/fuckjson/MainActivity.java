package com.example.fuckjson;
import android.app.Dialog;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import com.example.fuckjson.common.Memory;
import android.content.Context;




public class MainActivity extends AppCompatActivity {



    public static final String SHARED_PREFS = "sharedPrefs";
    public static final int MONEY = 0;
    public static int playerMoney;


    TextView playerMoney_tv;
    Dialog checkCarDialog;
    public int a;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        checkCarDialog = new Dialog(this);
        playerMoney_tv = findViewById(R.id.playerMoney_tv);

        test();



    }


    public void checkCar(View v){
        TextView txtclose;
        Button btnBuyCar;
        checkCarDialog.setContentView(R.layout.check_car_popup);
        txtclose = (TextView) checkCarDialog.findViewById(R.id.txtclose);
        btnBuyCar = (Button) checkCarDialog.findViewById(R.id.buyCar_btn);
        txtclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkCarDialog.dismiss();
            }
        });
        checkCarDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        checkCarDialog.show();
    }


    public void test(){
        Memory.getMoneyData();

    }









}