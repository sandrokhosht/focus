package com.example.fuckjson.common;
import android.content.SharedPreferences;
import android.widget.TextView;
import android.content.Context;

import com.example.fuckjson.GameApplication;
import static android.content.Context.MODE_PRIVATE;

import com.example.fuckjson.MainActivity;



public class Memory {

    public static final String SHARED_PREFS = "sharedPrefs";
    public static final int MONEY = 0;
    public static int playerMoney;



    public static void getMoneyData(){
        SharedPreferences sp = GameApplication.getContext().getApplicationContext().getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);
        int myMoneyValue = sp.getInt("MONEY", 0);
        // playerMoney = myMoneyValue;

    }

    public static void changeMoneyData(String moneyToChange){
        SharedPreferences sp = GameApplication.getContext().getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        int valueToChange=Integer.parseInt(moneyToChange);  // converting string to int
        playerMoney+=valueToChange; // adding value to moneyMoney
        editor.putInt("MONEY", playerMoney); // put value to its key
        editor.apply();
    }


}
